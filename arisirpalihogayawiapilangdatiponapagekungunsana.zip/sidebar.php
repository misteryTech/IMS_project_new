<div class="sidebar" style="background-color: #2f2f2f; color: white; padding: 20px; position: fixed; top: 0; left: 0; width: 220px; height: 100vh;">
    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="dashboard.php" style="color: white; text-decoration: none; padding: 8px; display: block;">Dashboard</a></li>
        <li><a href="meat_registration_r.php" style="color: white; text-decoration: none; padding: 8px; display: block;">Meat Registration</a></li>
        <li><a href="meat_view.php" style="color: white; text-decoration: none; padding: 8px; display: block;">View Meat</a></li>
        <li><a href="supplier_page.php" style="color: white; text-decoration: none; padding: 8px; display: block;">Supplier Registration</a></li>
        <li><a href="supplier_view.php" style="color: white; text-decoration: none; padding: 8px; display: block;">View Supplier</a></li>
        <li><a href="order_page.php" style="color: white; text-decoration: none; padding: 8px; display: block;">Order</a></li>
        <li><a href="logout.php" style="color: white; text-decoration: none; padding: 8px; display: block;">Logout</a></li>
    </ul>
</div>
