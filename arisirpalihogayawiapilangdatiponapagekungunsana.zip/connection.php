<?php
    $localhost = "localhost";
    $username = "root";  // username
    $password = "";   // password
    $database = "ims_db"; // database




    $connection  = mysqli_connect($localhost, $username, $password, $database);


?>